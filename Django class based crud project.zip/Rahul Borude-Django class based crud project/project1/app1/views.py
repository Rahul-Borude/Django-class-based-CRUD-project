
from django.views.generic import ListView
from django.views.generic.edit  import CreateView, UpdateView, DeleteView
from app1.models import Student


# Create your views here.
class StudentView(CreateView):
    model = Student
    template_name = "app1/student_form.html"
    fields = "__all__"
    success_url = '/a1/sd/'

class Studentdata(ListView):
    model = Student
    
    
class UpdateView(UpdateView):
    model = Student
    fields = "__all__"
    success_url = '/a1/sd/'

class Delete(DeleteView):
    model = Student
    success_url = '/a1/sd/'
    
    