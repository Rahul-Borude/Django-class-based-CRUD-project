from django.urls import path
from app1.views import StudentView, Studentdata, UpdateView, Delete

urlpatterns = [
    path('sv/', StudentView.as_view(), name='studenturl'),
    path('sd/', Studentdata.as_view(), name='studentdataurl'),
    path("update/<int:pk>/", UpdateView.as_view(), name="updateurl"),
    path("delete/<int:pk>",Delete.as_view(),name="deleteurl")
]